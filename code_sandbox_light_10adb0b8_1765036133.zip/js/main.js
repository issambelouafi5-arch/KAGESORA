// Main Application JavaScript

class App {
    constructor() {
        this.init();
    }

    init() {
        this.bindGlobalEvents();
        this.setupNavigation();
        this.setupAdminFeatures();
        
        // Initialize modules
        if (window.authManager) {
            window.authManager.updateUI();
        }
        
        if (window.postsManager) {
            window.postsManager.loadPosts();
        }
    }

    bindGlobalEvents() {
        // Smooth scrolling for navigation links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });

        // Handle offline/online status
        window.addEventListener('online', () => {
            this.showNotification('Back online!', 'success');
        });

        window.addEventListener('offline', () => {
            this.showNotification('You are offline. Some features may not work.', 'warning');
        });

        // Handle page visibility changes
        document.addEventListener('visibilitychange', () => {
            if (!document.hidden) {
                // Refresh data when page becomes visible
                this.refreshData();
            }
        });
    }

    setupNavigation() {
        // Navigation links
        document.getElementById('nav-home').addEventListener('click', (e) => {
            e.preventDefault();
            this.navigateTo('home');
        });

        document.getElementById('nav-categories').addEventListener('click', (e) => {
            e.preventDefault();
            this.navigateTo('categories');
        });

        document.getElementById('nav-teachers').addEventListener('click', (e) => {
            e.preventDefault();
            this.navigateTo('teachers');
        });

        // User menu links
        document.getElementById('profile-link').addEventListener('click', (e) => {
            e.preventDefault();
            this.navigateTo('profile');
        });

        document.getElementById('my-posts-link').addEventListener('click', (e) => {
            e.preventDefault();
            this.navigateTo('my-posts');
        });

        document.getElementById('admin-panel').addEventListener('click', (e) => {
            e.preventDefault();
            this.navigateTo('admin');
        });
    }

    setupAdminFeatures() {
        // Check if current user is admin and show admin features
        if (window.authManager && window.authManager.isLoggedIn()) {
            const currentUser = window.authManager.getCurrentUser();
            if (currentUser.is_admin) {
                this.enableAdminFeatures();
            }
        }
    }

    enableAdminFeatures() {
        // Add admin-specific functionality
        console.log('Admin features enabled');
        
        // Add moderation tools to posts and comments
        this.addModerationTools();
    }

    addModerationTools() {
        // This will be called when posts are rendered to add admin controls
        document.addEventListener('postsRendered', () => {
            if (window.authManager && window.authManager.isLoggedIn()) {
                const currentUser = window.authManager.getCurrentUser();
                if (currentUser.is_admin) {
                    this.addAdminControls();
                }
            }
        });
    }

    addAdminControls() {
        // Add admin controls to posts
        document.querySelectorAll('.post-card').forEach(postCard => {
            const postId = postCard.dataset.postId;
            const controls = postCard.querySelector('.post-stats');
            
            if (controls && !controls.querySelector('.admin-controls')) {
                const adminControls = document.createElement('div');
                adminControls.className = 'admin-controls';
                adminControls.innerHTML = `
                    <button class="btn btn-sm btn-outline-danger" onclick="app.moderatePost('${postId}', 'hide')" title="Hide Post">
                        <i class="bi bi-eye-slash"></i>
                    </button>
                    <button class="btn btn-sm btn-outline-warning" onclick="app.moderatePost('${postId}', 'warn')" title="Warn User">
                        <i class="bi bi-exclamation-triangle"></i>
                    </button>
                `;
                controls.appendChild(adminControls);
            }
        });
    }

    navigateTo(section) {
        // Update navigation active state
        document.querySelectorAll('.navbar-nav .nav-link').forEach(link => {
            link.classList.remove('active');
        });

        // Update content based on section
        switch (section) {
            case 'home':
                document.getElementById('nav-home').classList.add('active');
                this.showHomePage();
                break;
            case 'categories':
                document.getElementById('nav-categories').classList.add('active');
                this.showCategoriesPage();
                break;
            case 'teachers':
                document.getElementById('nav-teachers').classList.add('active');
                this.showTeachersPage();
                break;
            case 'profile':
                this.showProfilePage();
                break;
            case 'my-posts':
                this.showMyPostsPage();
                break;
            case 'admin':
                this.showAdminPanel();
                break;
            default:
                this.showHomePage();
        }

        // Update URL without page reload
        history.pushState({ section }, '', `#${section}`);
    }

    showHomePage() {
        // Default home page - posts feed
        if (window.postsManager) {
            window.postsManager.loadPosts(true);
        }
    }

    showCategoriesPage() {
        // Show categories view
        const container = document.getElementById('posts-container');
        container.innerHTML = `
            <div class="row">
                <div class="col-12">
                    <h2 class="mb-4">Categories</h2>
                    <div class="row">
                        ${this.getCategories().map(category => `
                            <div class="col-md-4 mb-3">
                                <div class="card h-100 cursor-pointer" onclick="app.filterByCategory('${category.name}')">
                                    <div class="card-body">
                                        <div class="d-flex align-items-center mb-3">
                                            <i class="bi ${category.icon} fs-2 text-primary me-3"></i>
                                            <h5 class="card-title mb-0">${category.name}</h5>
                                        </div>
                                        <p class="card-text">${category.description}</p>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <span class="badge bg-primary">${category.count} posts</span>
                                            <button class="btn btn-sm btn-outline-primary">View Posts</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            </div>
        `;
    }

    showTeachersPage() {
        // Show teachers directory
        this.loadTeachers().then(teachers => {
            const container = document.getElementById('posts-container');
            container.innerHTML = `
                <div class="row">
                    <div class="col-12">
                        <h2 class="mb-4">Community Teachers</h2>
                        <div class="row">
                            ${teachers.map(teacher => `
                                <div class="col-md-6 col-lg-4 mb-4">
                                    <div class="card h-100">
                                        <div class="card-body text-center">
                                            <div class="mb-3">
                                                <img src="${teacher.avatar_url}" alt="${teacher.full_name}" 
                                                     class="rounded-circle" style="width: 80px; height: 80px; object-fit: cover;">
                                            </div>
                                            <h5 class="card-title">${teacher.full_name}</h5>
                                            <p class="text-muted mb-2">@${teacher.username}</p>
                                            <p class="card-text">
                                                <small>${teacher.school_name || 'School not specified'}</small><br>
                                                <small>${teacher.teaching_level || 'Level not specified'}</small>
                                            </p>
                                            <div class="d-flex justify-content-center">
                                                ${teacher.is_admin ? '<span class="admin-badge ms-2">ADMIN</span>' : ''}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                </div>
            `;
        });
    }

    showProfilePage() {
        if (!window.authManager.requireAuth(() => this.showProfilePage())) {
            return;
        }

        const currentUser = window.authManager.getCurrentUser();
        const container = document.getElementById('posts-container');
        
        container.innerHTML = `
            <div class="row">
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-body text-center">
                            <div class="mb-3">
                                <img src="${currentUser.avatar_url}" alt="${currentUser.full_name}" 
                                     class="rounded-circle" style="width: 120px; height: 120px; object-fit: cover;">
                            </div>
                            <h4>${currentUser.full_name}</h4>
                            <p class="text-muted">@${currentUser.username}</p>
                            <p class="mb-2"><strong>Email:</strong> ${currentUser.email}</p>
                            <p class="mb-2"><strong>School:</strong> ${currentUser.school_name || 'Not specified'}</p>
                            <p class="mb-2"><strong>Level:</strong> ${currentUser.teaching_level || 'Not specified'}</p>
                            <p class="mb-2"><strong>Experience:</strong> ${currentUser.years_experience || 0} years</p>
                            ${currentUser.is_admin ? '<span class="admin-badge">ADMIN</span>' : ''}
                        </div>
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">About Me</h5>
                            <p>${currentUser.bio || 'No bio provided.'}</p>
                            <hr>
                            <h5 class="card-title">Statistics</h5>
                            <div class="row">
                                <div class="col-4 text-center">
                                    <h4 id="user-posts-count">0</h4>
                                    <p class="text-muted">Posts</p>
                                </div>
                                <div class="col-4 text-center">
                                    <h4 id="user-comments-count">0</h4>
                                    <p class="text-muted">Comments</p>
                                </div>
                                <div class="col-4 text-center">
                                    <h4 id="user-joined-date">${new Date(currentUser.created_at).toLocaleDateString()}</h4>
                                    <p class="text-muted">Joined</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;

        // Load user statistics
        this.loadUserStats(currentUser.id);
    }

    showMyPostsPage() {
        if (!window.authManager.requireAuth(() => this.showMyPostsPage())) {
            return;
        }

        const currentUser = window.authManager.getCurrentUser();
        
        // Filter posts by current user
        if (window.postsManager) {
            window.postsManager.currentFilter = 'my-posts';
            window.postsManager.userFilter = currentUser.id;
            window.postsManager.loadPosts(true);
        }
    }

    showAdminPanel() {
        if (!window.authManager.requireAuth(() => this.showAdminPanel())) {
            return;
        }

        const currentUser = window.authManager.getCurrentUser();
        if (!currentUser.is_admin) {
            this.showNotification('Access denied. Admin privileges required.', 'danger');
            return;
        }

        const container = document.getElementById('posts-container');
        container.innerHTML = `
            <div class="row">
                <div class="col-12">
                    <h2 class="mb-4">Admin Panel</h2>
                    <div class="row">
                        <div class="col-md-3">
                            <div class="card text-center">
                                <div class="card-body">
                                    <i class="bi bi-people display-4 text-primary mb-3"></i>
                                    <h4 id="admin-users-count">0</h4>
                                    <p class="text-muted">Total Users</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card text-center">
                                <div class="card-body">
                                    <i class="bi bi-file-text display-4 text-success mb-3"></i>
                                    <h4 id="admin-posts-count">0</h4>
                                    <p class="text-muted">Total Posts</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card text-center">
                                <div class="card-body">
                                    <i class="bi bi-chat display-4 text-info mb-3"></i>
                                    <h4 id="admin-comments-count">0</h4>
                                    <p class="text-muted">Total Comments</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card text-center">
                                <div class="card-body">
                                    <i class="bi bi-flag display-4 text-warning mb-3"></i>
                                    <h4 id="admin-reports-count">0</h4>
                                    <p class="text-muted">Reports</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="card mt-4">
                        <div class="card-header">
                            <h5 class="mb-0">Recent Activity</h5>
                        </div>
                        <div class="card-body">
                            <div id="admin-activity-feed">
                                <p class="text-muted">Loading activity...</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;

        this.loadAdminStats();
    }

    filterByCategory(category) {
        if (window.postsManager) {
            window.postsManager.filterByCategory(category);
        }
    }

    loadUserStats(userId) {
        // Load user statistics
        Promise.all([
            fetch(`tables/posts?user_id=${userId}`).then(r => r.json()),
            fetch(`tables/comments?user_id=${userId}`).then(r => r.json())
        ]).then(([postsData, commentsData]) => {
            const postsCount = postsData.data ? postsData.data.length : 0;
            const commentsCount = commentsData.data ? commentsData.data.length : 0;
            
            document.getElementById('user-posts-count').textContent = postsCount;
            document.getElementById('user-comments-count').textContent = commentsCount;
        });
    }

    loadTeachers() {
        return fetch('tables/users')
            .then(response => response.json())
            .then(data => data.data || [])
            .catch(() => []);
    }

    loadAdminStats() {
        Promise.all([
            fetch('tables/users').then(r => r.json()),
            fetch('tables/posts').then(r => r.json()),
            fetch('tables/comments').then(r => r.json())
        ]).then(([usersData, postsData, commentsData]) => {
            document.getElementById('admin-users-count').textContent = usersData.data ? usersData.data.length : 0;
            document.getElementById('admin-posts-count').textContent = postsData.data ? postsData.data.length : 0;
            document.getElementById('admin-comments-count').textContent = commentsData.data ? commentsData.data.length : 0;
            document.getElementById('admin-reports-count').textContent = '0';
        });
    }

    moderatePost(postId, action) {
        // Implement post moderation
        console.log(`Moderating post ${postId} with action: ${action}`);
        this.showNotification(`Post ${action} action taken`, 'info');
    }

    refreshData() {
        // Refresh current view
        const currentSection = window.location.hash.replace('#', '') || 'home';
        this.navigateTo(currentSection);
    }

    getCategories() {
        return [
            {
                name: 'Classroom Activities',
                description: 'Fun and engaging activities for your students',
                icon: 'bi-puzzle',
                count: 0
            },
            {
                name: 'Teaching Methods',
                description: 'Effective teaching strategies and techniques',
                icon: 'bi-lightbulb',
                count: 0
            },
            {
                name: 'Lesson Plans',
                description: 'Complete lesson plans and unit plans',
                icon: 'bi-book',
                count: 0
            },
            {
                name: 'Student Engagement',
                description: 'Ideas to keep students motivated and involved',
                icon: 'bi-people',
                count: 0
            },
            {
                name: 'Classroom Management',
                description: 'Tips for maintaining classroom discipline',
                icon: 'bi-shield-check',
                count: 0
            },
            {
                name: 'Assessment Ideas',
                description: 'Creative ways to assess student learning',
                icon: 'bi-clipboard-check',
                count: 0
            }
        ];
    }

    showNotification(message, type = 'info') {
        if (window.authManager) {
            window.authManager.showNotification(message, type);
        } else {
            // Fallback notification
            alert(message);
        }
    }
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.app = new App();
});

// Handle browser back/forward buttons
window.addEventListener('popstate', (e) => {
    if (e.state && e.state.section) {
        window.app.navigateTo(e.state.section);
    }
});