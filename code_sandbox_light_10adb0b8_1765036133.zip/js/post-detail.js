// Post Detail Page Module
class PostDetailManager {
    constructor() {
        this.currentPost = null;
        this.currentUser = null;
        this.postId = null;
        this.init();
    }

    init() {
        this.loadCurrentUser();
        this.extractPostId();
        if (this.postId) {
            this.loadPost();
        } else {
            this.showError('Post not found');
        }
        this.bindEvents();
    }

    bindEvents() {
        // Share button
        document.getElementById('share-post-btn')?.addEventListener('click', () => this.sharePost());
        
        // Back button
        document.getElementById('back-btn')?.addEventListener('click', () => window.history.back());
    }

    loadCurrentUser() {
        if (window.authManager) {
            this.currentUser = window.authManager.getCurrentUser();
            this.updateUI();
        }
    }

    updateUI() {
        // Update auth UI
        const authButtons = document.getElementById('auth-buttons');
        const userMenu = document.getElementById('user-menu');
        const usernameDisplay = document.getElementById('username-display');
        const adminPanel = document.getElementById('admin-panel');

        if (this.currentUser) {
            authButtons.classList.add('d-none');
            userMenu.classList.remove('d-none');
            usernameDisplay.textContent = this.currentUser.username;
            
            if (this.currentUser.is_admin) {
                adminPanel.style.display = 'block';
            }
        } else {
            authButtons.classList.remove('d-none');
            userMenu.classList.add('d-none');
        }
    }

    extractPostId() {
        const urlParams = new URLSearchParams(window.location.search);
        this.postId = urlParams.get('id');
    }

    async loadPost() {
        try {
            const response = await fetch(`tables/posts/${this.postId}`);
            if (!response.ok) {
                throw new Error('Post not found');
            }
            
            this.currentPost = await response.json();
            
            // Fetch author info
            const usersResponse = await fetch('tables/users');
            const usersData = await usersResponse.json();
            const users = usersData.data || [];
            
            this.currentPost.author = users.find(u => u.id === this.currentPost.user_id) || {
                username: 'Unknown',
                full_name: 'Unknown User',
                avatar_url: 'https://ui-avatars.com/api/?name=U&background=cccccc&color=fff'
            };

            this.renderPost();
            this.loadComments();
            this.loadRelatedPosts();
            this.loadAuthorStats();
            
        } catch (error) {
            console.error('Error loading post:', error);
            this.showError('Failed to load post');
        }
    }

    renderPost() {
        if (!this.currentPost) return;

        const container = document.getElementById('post-content');
        const timeAgo = this.getTimeAgo(this.currentPost.created_at);
        const content = this.renderContent(this.currentPost.content);
        const upvotes = this.currentPost.upvotes || 0;
        const downvotes = this.currentPost.downvotes || 0;

        container.innerHTML = `
            <div class="card">
                <div class="card-body">
                    <div class="post-header mb-4">
                        <div class="post-avatar">
                            <img src="${this.currentPost.author.avatar_url}" alt="${this.currentPost.author.full_name}" 
                                 style="width: 100%; height: 100%; border-radius: 50%; object-fit: cover;">
                        </div>
                        <div class="post-meta">
                            <div class="post-author">${this.currentPost.author.full_name}</div>
                            <div class="post-time">@${this.currentPost.author.username} • ${timeAgo}</div>
                        </div>
                        <div class="ms-auto">
                            <span class="post-category">${this.currentPost.category}</span>
                        </div>
                    </div>
                    
                    <h1 class="post-title mb-4">${this.escapeHtml(this.currentPost.title)}</h1>
                    <div class="post-content mb-4">${content}</div>
                    
                    <div class="post-stats border-top pt-3">
                        <div class="vote-buttons">
                            <button class="vote-btn ${this.currentPost.userVote === 'up' ? 'voted-up' : ''}" 
                                    onclick="postDetail.votePost('up')" title="Upvote">
                                <i class="bi bi-arrow-up-circle"></i>
                            </button>
                            <span class="vote-count">${upvotes - downvotes}</span>
                            <button class="vote-btn ${this.currentPost.userVote === 'down' ? 'voted-down' : ''}" 
                                    onclick="postDetail.votePost('down')" title="Downvote">
                                <i class="bi bi-arrow-down-circle"></i>
                            </button>
                        </div>
                        
                        <div class="post-stat" onclick="postDetail.sharePost()">
                            <i class="bi bi-share"></i>
                            <span>Share</span>
                        </div>
                        
                        ${this.currentUserCanEdit() ? `
                            <div class="post-stat" onclick="postDetail.editPost()">
                                <i class="bi bi-pencil"></i>
                                <span>Edit</span>
                            </div>
                            <div class="post-stat" onclick="postDetail.deletePost()">
                                <i class="bi bi-trash"></i>
                                <span>Delete</span>
                            </div>
                        ` : ''}
                    </div>
                </div>
            </div>
        `;

        // Update post stats
        document.getElementById('post-upvotes').textContent = upvotes;
        document.getElementById('post-downvotes').textContent = downvotes;
        document.getElementById('post-views').textContent = this.currentPost.views || 0;

        // Show comments section
        document.getElementById('comments-section').style.display = 'block';
    }

    renderContent(content) {
        let html = this.escapeHtml(content);
        
        // Simple formatting
        html = html
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/g, '<em>$1</em>')
            .replace(/`(.*?)`/g, '<code>$1</code>')
            .replace(/\n/g, '<br>');
        
        return html;
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    getTimeAgo(timestamp) {
        const now = new Date();
        const postTime = new Date(timestamp);
        const diffMs = now - postTime;
        const diffMins = Math.floor(diffMs / 60000);
        const diffHours = Math.floor(diffMs / 3600000);
        const diffDays = Math.floor(diffMs / 86400000);

        if (diffMins < 1) return 'just now';
        if (diffMins < 60) return `${diffMins}m ago`;
        if (diffHours < 24) return `${diffHours}h ago`;
        if (diffDays < 30) return `${diffDays}d ago`;
        return postTime.toLocaleDateString();
    }

    currentUserCanEdit() {
        if (!this.currentUser || !this.currentPost) return false;
        return this.currentUser.id === this.currentPost.user_id || this.currentUser.is_admin;
    }

    async loadComments() {
        if (window.commentsManager) {
            window.commentsManager.setCurrentPost(this.postId);
        }
    }

    async loadRelatedPosts() {
        try {
            const response = await fetch(`tables/posts?category=${encodeURIComponent(this.currentPost.category)}&limit=5`);
            const data = await response.json();
            
            if (data.data && data.data.length > 0) {
                const relatedPosts = data.data.filter(p => p.id !== this.postId).slice(0, 3);
                
                const container = document.getElementById('related-posts');
                container.innerHTML = relatedPosts.map(post => `
                    <div class="mb-3">
                        <h6><a href="post.html?id=${post.id}" class="text-decoration-none">${this.escapeHtml(post.title)}</a></h6>
                        <small class="text-muted">${this.getTimeAgo(post.created_at)}</small>
                    </div>
                `).join('');
            } else {
                document.getElementById('related-posts').innerHTML = '<p class="text-muted">No related posts found.</p>';
            }
        } catch (error) {
            console.error('Error loading related posts:', error);
        }
    }

    async loadAuthorStats() {
        try {
            // Fetch author's posts and comments count
            const [postsResponse, commentsResponse] = await Promise.all([
                fetch(`tables/posts?user_id=${this.currentPost.user_id}`),
                fetch(`tables/comments?user_id=${this.currentPost.user_id}`)
            ]);

            const postsData = await postsResponse.json();
            const commentsData = await commentsResponse.json();

            const postsCount = postsData.data ? postsData.data.length : 0;
            const commentsCount = commentsData.data ? commentsData.data.length : 0;

            // Update author info
            document.getElementById('author-avatar-img').src = this.currentPost.author.avatar_url;
            document.getElementById('author-name').textContent = this.currentPost.author.full_name;
            document.getElementById('author-username').textContent = `@${this.currentPost.author.username}`;
            document.getElementById('author-bio').textContent = this.currentPost.author.bio || 'No bio provided.';
            document.getElementById('author-posts-count').textContent = postsCount;
            document.getElementById('author-comments-count').textContent = commentsCount;
            document.getElementById('author-joined').textContent = new Date(this.currentPost.author.created_at).toLocaleDateString();

        } catch (error) {
            console.error('Error loading author stats:', error);
        }
    }

    async votePost(voteType) {
        if (!this.currentUser) {
            this.showNotification('Please login to vote', 'warning');
            return;
        }

        try {
            // Update vote count
            if (voteType === 'up') {
                this.currentPost.upvotes = (this.currentPost.upvotes || 0) + 1;
                this.currentPost.userVote = 'up';
            } else {
                this.currentPost.downvotes = (this.currentPost.downvotes || 0) + 1;
                this.currentPost.userVote = 'down';
            }

            // Save to database
            await this.updatePost();
            
            // Re-render post
            this.renderPost();
            
            this.showNotification('Vote recorded!', 'success');
        } catch (error) {
            console.error('Error voting post:', error);
            this.showNotification('Failed to record vote', 'danger');
        }
    }

    async updatePost() {
        try {
            const response = await fetch(`tables/posts/${this.postId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(this.currentPost)
            });
            
            if (!response.ok) {
                throw new Error('Failed to update post');
            }
            
            return await response.json();
        } catch (error) {
            console.error('Error updating post:', error);
            throw error;
        }
    }

    sharePost() {
        const url = `${window.location.origin}/post.html?id=${this.postId}`;
        const title = this.currentPost.title;
        
        if (navigator.share) {
            navigator.share({
                title: title,
                text: 'Check out this teaching idea from MET Community',
                url: url
            });
        } else {
            navigator.clipboard.writeText(url).then(() => {
                this.showNotification('Link copied to clipboard!', 'success');
            });
        }
    }

    editPost() {
        this.showNotification('Edit functionality coming soon!', 'info');
    }

    deletePost() {
        if (confirm('Are you sure you want to delete this post?')) {
            this.showNotification('Delete functionality coming soon!', 'info');
        }
    }

    showError(message) {
        const container = document.getElementById('post-content');
        container.innerHTML = `
            <div class="alert alert-danger" role="alert">
                <i class="bi bi-exclamation-triangle me-2"></i>${message}
            </div>
            <div class="text-center mt-4">
                <a href="index.html" class="btn btn-primary">Back to Home</a>
            </div>
        `;
    }

    showNotification(message, type = 'info') {
        if (window.authManager) {
            window.authManager.showNotification(message, type);
        } else {
            // Fallback
            alert(message);
        }
    }
}

// Initialize post detail manager
window.postDetail = new PostDetailManager();