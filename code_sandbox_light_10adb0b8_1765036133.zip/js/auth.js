// Authentication Module
class AuthManager {
    constructor() {
        this.currentUser = null;
        this.init();
    }

    init() {
        this.loadCurrentUser();
        this.bindEvents();
        this.updateUI();
    }

    bindEvents() {
        // Login form
        document.getElementById('login-btn').addEventListener('click', (e) => this.handleLogin(e));
        document.getElementById('login-form').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.handleLogin(e);
        });

        // Register form
        document.getElementById('register-btn').addEventListener('click', (e) => this.handleRegister(e));
        document.getElementById('register-form').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.handleRegister(e);
        });

        // Logout
        document.getElementById('logout-btn').addEventListener('click', (e) => this.handleLogout(e));
    }

    async handleLogin(e) {
        e.preventDefault();
        const username = document.getElementById('login-username').value.trim();
        const password = document.getElementById('login-password').value;
        const errorDiv = document.getElementById('login-error');

        if (!username || !password) {
            this.showError(errorDiv, 'Please fill in all fields');
            return;
        }

        try {
            const users = await this.fetchUsers();
            const user = users.find(u => 
                (u.username === username || u.email === username) && 
                u.password === this.hashPassword(password) &&
                u.is_active
            );

            if (user) {
                this.setCurrentUser(user);
                this.closeModal('loginModal');
                this.clearForm('login-form');
                this.showNotification('Login successful!', 'success');
                
                // Reload posts
                if (window.postsManager) {
                    window.postsManager.loadPosts();
                }
            } else {
                this.showError(errorDiv, 'Invalid credentials or account inactive');
            }
        } catch (error) {
            console.error('Login error:', error);
            this.showError(errorDiv, 'Login failed. Please try again.');
        }
    }

    async handleRegister(e) {
        e.preventDefault();
        const formData = {
            username: document.getElementById('register-username').value.trim(),
            email: document.getElementById('register-email').value.trim(),
            password: document.getElementById('register-password').value,
            confirmPassword: document.getElementById('register-confirm-password').value,
            full_name: document.getElementById('register-fullname').value.trim(),
            school_name: document.getElementById('register-school').value.trim(),
            teaching_level: document.getElementById('register-level').value,
            years_experience: parseInt(document.getElementById('register-experience').value) || 0,
            bio: document.getElementById('register-bio').value.trim()
        };

        const errorDiv = document.getElementById('register-error');

        // Validation
        if (!this.validateRegistration(formData, errorDiv)) {
            return;
        }

        try {
            // Check if username or email already exists
            const users = await this.fetchUsers();
            if (users.some(u => u.username === formData.username)) {
                this.showError(errorDiv, 'Username already exists');
                return;
            }
            if (users.some(u => u.email === formData.email)) {
                this.showError(errorDiv, 'Email already registered');
                return;
            }

            // Create new user
            const newUser = {
                id: this.generateId(),
                username: formData.username,
                email: formData.email,
                password: this.hashPassword(formData.password),
                full_name: formData.full_name,
                school_name: formData.school_name,
                teaching_level: formData.teaching_level,
                years_experience: formData.years_experience,
                bio: formData.bio,
                avatar_url: this.generateAvatar(formData.full_name),
                is_admin: false,
                is_active: true,
                created_at: new Date().toISOString()
            };

            await this.createUser(newUser);
            
            // Auto login after registration
            this.setCurrentUser(newUser);
            this.closeModal('registerModal');
            this.clearForm('register-form');
            this.showNotification('Registration successful! Welcome to the community!', 'success');
            
            // Reload posts
            if (window.postsManager) {
                window.postsManager.loadPosts();
            }
            
        } catch (error) {
            console.error('Registration error:', error);
            this.showError(errorDiv, 'Registration failed. Please try again.');
        }
    }

    validateRegistration(data, errorDiv) {
        if (!data.username || data.username.length < 3) {
            this.showError(errorDiv, 'Username must be at least 3 characters');
            return false;
        }
        
        if (!/^[a-zA-Z0-9_]+$/.test(data.username)) {
            this.showError(errorDiv, 'Username can only contain letters, numbers, and underscores');
            return false;
        }
        
        if (!data.email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
            this.showError(errorDiv, 'Please enter a valid email address');
            return false;
        }
        
        if (!data.password || data.password.length < 6) {
            this.showError(errorDiv, 'Password must be at least 6 characters');
            return false;
        }
        
        if (data.password !== data.confirmPassword) {
            this.showError(errorDiv, 'Passwords do not match');
            return false;
        }
        
        if (!data.full_name || data.full_name.length < 2) {
            this.showError(errorDiv, 'Please enter your full name');
            return false;
        }
        
        return true;
    }

    handleLogout(e) {
        e.preventDefault();
        this.currentUser = null;
        localStorage.removeItem('currentUser');
        this.updateUI();
        this.showNotification('Logged out successfully', 'info');
        
        // Reload posts
        if (window.postsManager) {
            window.postsManager.loadPosts();
        }
    }

    setCurrentUser(user) {
        this.currentUser = user;
        localStorage.setItem('currentUser', JSON.stringify(user));
        this.updateUI();
    }

    loadCurrentUser() {
        const stored = localStorage.getItem('currentUser');
        if (stored) {
            try {
                this.currentUser = JSON.parse(stored);
            } catch (e) {
                localStorage.removeItem('currentUser');
            }
        }
    }

    updateUI() {
        const authButtons = document.getElementById('auth-buttons');
        const userMenu = document.getElementById('user-menu');
        const createPostBtn = document.getElementById('create-post-btn');
        const usernameDisplay = document.getElementById('username-display');
        const adminPanel = document.getElementById('admin-panel');

        if (this.currentUser) {
            authButtons.classList.add('d-none');
            userMenu.classList.remove('d-none');
            createPostBtn.style.display = 'inline-block';
            usernameDisplay.textContent = this.currentUser.username;
            
            // Show admin panel if user is admin
            if (this.currentUser.is_admin) {
                adminPanel.style.display = 'block';
            } else {
                adminPanel.style.display = 'none';
            }
        } else {
            authButtons.classList.remove('d-none');
            userMenu.classList.add('d-none');
            createPostBtn.style.display = 'none';
        }
    }

    async fetchUsers() {
        try {
            const response = await fetch('tables/users');
            const data = await response.json();
            return data.data || [];
        } catch (error) {
            console.error('Error fetching users:', error);
            return [];
        }
    }

    async createUser(user) {
        try {
            const response = await fetch('tables/users', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(user)
            });
            
            if (!response.ok) {
                throw new Error('Failed to create user');
            }
            
            return await response.json();
        } catch (error) {
            console.error('Error creating user:', error);
            throw error;
        }
    }

    hashPassword(password) {
        // Simple hash for demo purposes - in production, use proper bcrypt
        let hash = 0;
        for (let i = 0; i < password.length; i++) {
            const char = password.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash = hash & hash;
        }
        return hash.toString();
    }

    generateId() {
        return 'user_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }

    generateAvatar(fullName) {
        const initials = fullName.split(' ').map(n => n[0]).join('').toUpperCase();
        const colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7', '#DDA0DD', '#98D8C8', '#F7DC6F'];
        const color = colors[Math.floor(Math.random() * colors.length)];
        
        return `https://ui-avatars.com/api/?name=${encodeURIComponent(initials)}&background=${color.replace('#', '')}&color=fff&size=128`;
    }

    showError(element, message) {
        element.textContent = message;
        element.classList.remove('d-none');
        setTimeout(() => {
            element.classList.add('d-none');
        }, 5000);
    }

    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
        notification.style.cssText = 'top: 100px; right: 20px; z-index: 9999; min-width: 300px;';
        notification.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 5000);
    }

    closeModal(modalId) {
        const modal = bootstrap.Modal.getInstance(document.getElementById(modalId));
        if (modal) {
            modal.hide();
        }
    }

    clearForm(formId) {
        const form = document.getElementById(formId);
        if (form) {
            form.reset();
        }
    }

    isLoggedIn() {
        return !!this.currentUser;
    }

    getCurrentUser() {
        return this.currentUser;
    }

    requireAuth(callback) {
        if (this.isLoggedIn()) {
            return callback();
        } else {
            const loginModal = new bootstrap.Modal(document.getElementById('loginModal'));
            loginModal.show();
            return false;
        }
    }
}

// Initialize auth manager
window.authManager = new AuthManager();