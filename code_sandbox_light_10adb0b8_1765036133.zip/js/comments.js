// Comments Management Module
class CommentsManager {
    constructor() {
        this.comments = [];
        this.currentPostId = null;
        this.currentUser = null;
        this.init();
    }

    init() {
        this.bindEvents();
        this.loadCurrentUser();
    }

    bindEvents() {
        // Submit comment
        document.getElementById('submit-comment-btn')?.addEventListener('click', (e) => this.submitComment(e));
        
        // Comment form enter key
        document.getElementById('comment-content')?.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && e.ctrlKey) {
                this.submitComment(e);
            }
        });
    }

    setCurrentPost(postId) {
        this.currentPostId = postId;
        this.loadComments();
    }

    loadCurrentUser() {
        if (window.authManager) {
            this.currentUser = window.authManager.getCurrentUser();
            this.updateUI();
        }
    }

    updateUI() {
        const loginToComment = document.getElementById('login-to-comment');
        const addCommentForm = document.getElementById('add-comment-form');

        if (this.currentUser) {
            loginToComment.style.display = 'none';
            addCommentForm.style.display = 'block';
        } else {
            loginToComment.style.display = 'block';
            addCommentForm.style.display = 'none';
        }
    }

    async loadComments() {
        if (!this.currentPostId) return;

        try {
            const response = await fetch(`tables/comments?post_id=${this.currentPostId}`);
            const data = await response.json();
            
            if (data.data && data.data.length > 0) {
                // Fetch users to get comment author info
                const usersResponse = await fetch('tables/users');
                const usersData = await usersResponse.json();
                const users = usersData.data || [];
                
                // Merge comments with user data
                this.comments = data.data.map(comment => {
                    const author = users.find(u => u.id === comment.user_id);
                    return {
                        ...comment,
                        author: author || {
                            username: 'Unknown',
                            full_name: 'Unknown User',
                            avatar_url: 'https://ui-avatars.com/api/?name=U&background=cccccc&color=fff'
                        }
                    };
                });

                this.renderComments();
            } else {
                this.renderEmptyComments();
            }
        } catch (error) {
            console.error('Error loading comments:', error);
            this.showCommentsError('Failed to load comments');
        }
    }

    renderComments() {
        const container = document.getElementById('comments-list');
        
        if (this.comments.length === 0) {
            this.renderEmptyComments();
            return;
        }

        container.innerHTML = '';
        
        this.comments.forEach(comment => {
            const commentElement = this.createCommentElement(comment);
            container.appendChild(commentElement);
        });
    }

    createCommentElement(comment) {
        const commentDiv = document.createElement('div');
        commentDiv.className = 'comment-card card mb-3 fade-in';
        commentDiv.dataset.commentId = comment.id;

        const timeAgo = this.getTimeAgo(comment.created_at);
        const content = this.renderContent(comment.content);
        const upvotes = comment.upvotes || 0;
        const downvotes = comment.downvotes || 0;

        commentDiv.innerHTML = `
            <div class="card-body">
                <div class="comment-header">
                    <div class="comment-avatar">
                        <img src="${comment.author.avatar_url}" alt="${comment.author.full_name}" 
                             style="width: 100%; height: 100%; border-radius: 50%; object-fit: cover;">
                    </div>
                    <div class="flex-grow-1">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <strong>${comment.author.full_name}</strong>
                                <span class="text-muted">@${comment.author.username}</span>
                                <small class="text-muted ms-2">${timeAgo}</small>
                            </div>
                            ${this.currentUserCanEdit(comment) ? `
                                <div class="dropdown">
                                    <button class="btn btn-sm btn-link text-muted dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                        <i class="bi bi-three-dots-vertical"></i>
                                    </button>
                                    <ul class="dropdown-menu">
                                        <li><a class="dropdown-item" href="#" onclick="commentsManager.editComment('${comment.id}')">
                                            <i class="bi bi-pencil me-2"></i>Edit
                                        </a></li>
                                        <li><a class="dropdown-item text-danger" href="#" onclick="commentsManager.deleteComment('${comment.id}')">
                                            <i class="bi bi-trash me-2"></i>Delete
                                        </a></li>
                                    </ul>
                                </div>
                            ` : ''}
                        </div>
                        <div class="mt-2">${content}</div>
                        
                        <div class="vote-buttons mt-2">
                            <button class="vote-btn ${comment.userVote === 'up' ? 'voted-up' : ''}" 
                                    onclick="commentsManager.voteComment('${comment.id}', 'up')" title="Upvote">
                                <i class="bi bi-arrow-up-circle"></i>
                            </button>
                            <span class="vote-count">${upvotes - downvotes}</span>
                            <button class="vote-btn ${comment.userVote === 'down' ? 'voted-down' : ''}" 
                                    onclick="commentsManager.voteComment('${comment.id}', 'down')" title="Downvote">
                                <i class="bi bi-arrow-down-circle"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;

        return commentDiv;
    }

    renderContent(content) {
        let html = this.escapeHtml(content);
        
        // Simple formatting
        html = html
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/g, '<em>$1</em>')
            .replace(/`(.*?)`/g, '<code>$1</code>')
            .replace(/\n/g, '<br>');
        
        return html;
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    getTimeAgo(timestamp) {
        const now = new Date();
        const commentTime = new Date(timestamp);
        const diffMs = now - commentTime;
        const diffMins = Math.floor(diffMs / 60000);
        const diffHours = Math.floor(diffMs / 3600000);
        const diffDays = Math.floor(diffMs / 86400000);

        if (diffMins < 1) return 'just now';
        if (diffMins < 60) return `${diffMins}m ago`;
        if (diffHours < 24) return `${diffHours}h ago`;
        if (diffDays < 30) return `${diffDays}d ago`;
        return commentTime.toLocaleDateString();
    }

    currentUserCanEdit(comment) {
        if (!this.currentUser) return false;
        return this.currentUser.id === comment.user_id || this.currentUser.is_admin;
    }

    renderEmptyComments() {
        const container = document.getElementById('comments-list');
        container.innerHTML = `
            <div class="text-center py-4">
                <i class="bi bi-chat-dots display-4 text-muted mb-3"></i>
                <p class="text-muted">No comments yet</p>
                <p class="text-muted">Be the first to share your thoughts!</p>
            </div>
        `;
    }

    showCommentsError(message) {
        const container = document.getElementById('comments-list');
        container.innerHTML = `
            <div class="alert alert-danger" role="alert">
                <i class="bi bi-exclamation-triangle me-2"></i>${message}
            </div>
        `;
    }

    async submitComment(e) {
        e.preventDefault();
        
        if (!this.currentUser || !this.currentPostId) return;

        const content = document.getElementById('comment-content').value.trim();
        
        if (!content) {
            this.showNotification('Please write a comment', 'warning');
            return;
        }

        if (content.length < 2) {
            this.showNotification('Comment is too short', 'warning');
            return;
        }

        try {
            const newComment = {
                id: this.generateId(),
                post_id: this.currentPostId,
                user_id: this.currentUser.id,
                content: content,
                parent_id: null,
                upvotes: 0,
                downvotes: 0,
                is_published: true,
                created_at: new Date().toISOString(),
                updated_at: new Date().toISOString()
            };

            await this.createComment(newComment);
            
            // Clear form
            document.getElementById('comment-content').value = '';
            
            // Reload comments
            this.loadComments();
            
            this.showNotification('Comment posted successfully!', 'success');
            
        } catch (error) {
            console.error('Error submitting comment:', error);
            this.showNotification('Failed to post comment. Please try again.', 'danger');
        }
    }

    async createComment(comment) {
        try {
            const response = await fetch('tables/comments', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(comment)
            });
            
            if (!response.ok) {
                throw new Error('Failed to create comment');
            }
            
            return await response.json();
        } catch (error) {
            console.error('Error creating comment:', error);
            throw error;
        }
    }

    async voteComment(commentId, voteType) {
        if (!this.currentUser) {
            this.showNotification('Please login to vote', 'warning');
            return;
        }

        try {
            // Find comment
            const comment = this.comments.find(c => c.id === commentId);
            if (!comment) return;

            // Update vote count
            if (voteType === 'up') {
                comment.upvotes = (comment.upvotes || 0) + 1;
                comment.userVote = 'up';
            } else {
                comment.downvotes = (comment.downvotes || 0) + 1;
                comment.userVote = 'down';
            }

            // Save to database
            await this.updateComment(comment);
            
            // Re-render comments
            this.renderComments();
            
        } catch (error) {
            console.error('Error voting comment:', error);
            this.showNotification('Failed to record vote', 'danger');
        }
    }

    async updateComment(comment) {
        try {
            const response = await fetch(`tables/comments/${comment.id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(comment)
            });
            
            if (!response.ok) {
                throw new Error('Failed to update comment');
            }
            
            return await response.json();
        } catch (error) {
            console.error('Error updating comment:', error);
            throw error;
        }
    }

    editComment(commentId) {
        const comment = this.comments.find(c => c.id === commentId);
        if (!comment) return;

        // Create edit form
        const commentElement = document.querySelector(`[data-comment-id="${commentId}"]`);
        const contentDiv = commentElement.querySelector('.mt-2');
        
        const originalContent = comment.content;
        
        contentDiv.innerHTML = `
            <div class="mb-2">
                <textarea class="form-control" rows="3">${this.escapeHtml(originalContent)}</textarea>
            </div>
            <div class="d-flex gap-2">
                <button class="btn btn-sm btn-primary" onclick="commentsManager.saveEdit('${commentId}')">Save</button>
                <button class="btn btn-sm btn-secondary" onclick="commentsManager.cancelEdit('${commentId}', '${this.escapeHtml(originalContent)}')">Cancel</button>
            </div>
        `;
    }

    saveEdit(commentId) {
        const commentElement = document.querySelector(`[data-comment-id="${commentId}"]`);
        const textarea = commentElement.querySelector('textarea');
        const newContent = textarea.value.trim();
        
        if (!newContent) {
            this.showNotification('Comment cannot be empty', 'warning');
            return;
        }

        const comment = this.comments.find(c => c.id === commentId);
        if (comment) {
            comment.content = newContent;
            comment.updated_at = new Date().toISOString();
            
            this.updateComment(comment).then(() => {
                this.renderComments();
                this.showNotification('Comment updated successfully!', 'success');
            }).catch(() => {
                this.showNotification('Failed to update comment', 'danger');
            });
        }
    }

    cancelEdit(commentId, originalContent) {
        const commentElement = document.querySelector(`[data-comment-id="${commentId}"]`);
        const contentDiv = commentElement.querySelector('.mt-2');
        contentDiv.innerHTML = this.renderContent(originalContent);
    }

    deleteComment(commentId) {
        if (!confirm('Are you sure you want to delete this comment?')) {
            return;
        }

        const comment = this.comments.find(c => c.id === commentId);
        if (!comment) return;

        // Soft delete
        comment.is_published = false;
        comment.updated_at = new Date().toISOString();

        this.updateComment(comment).then(() => {
            this.comments = this.comments.filter(c => c.id !== commentId);
            this.renderComments();
            this.showNotification('Comment deleted successfully!', 'success');
        }).catch(() => {
            this.showNotification('Failed to delete comment', 'danger');
        });
    }

    showNotification(message, type = 'info') {
        if (window.authManager) {
            window.authManager.showNotification(message, type);
        } else {
            // Fallback
            alert(message);
        }
    }

    generateId() {
        return 'comment_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }
}

// Initialize comments manager
window.commentsManager = new CommentsManager();