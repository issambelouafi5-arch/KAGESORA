// Posts Management Module
class PostsManager {
    constructor() {
        this.posts = [];
        this.currentPage = 1;
        this.postsPerPage = 10;
        this.currentFilter = 'all';
        this.searchQuery = '';
        this.isLoading = false;
        this.init();
    }

    init() {
        this.bindEvents();
        this.loadPosts();
    }

    bindEvents() {
        // Create post button
        document.getElementById('create-post-btn').addEventListener('click', () => this.showCreatePostModal());
        
        // Category filters
        document.querySelectorAll('[data-category]').forEach(btn => {
            btn.addEventListener('click', (e) => this.filterByCategory(e.target.dataset.category));
        });
        
        // Search
        document.getElementById('search-btn').addEventListener('click', () => this.searchPosts());
        document.getElementById('search-input').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.searchPosts();
        });
        
        // Load more
        document.getElementById('load-more-btn').addEventListener('click', () => this.loadMorePosts());
    }

    async loadPosts(reset = false) {
        if (reset) {
            this.currentPage = 1;
            this.posts = [];
        }

        if (this.isLoading) return;
        this.isLoading = true;

        try {
            let url = 'tables/posts?page=' + this.currentPage + '&limit=' + this.postsPerPage;
            
            if (this.currentFilter !== 'all') {
                url += '&category=' + encodeURIComponent(this.currentFilter);
            }
            
            if (this.searchQuery) {
                url += '&search=' + encodeURIComponent(this.searchQuery);
            }

            const response = await fetch(url);
            const data = await response.json();
            
            if (data.data && data.data.length > 0) {
                // Fetch users to get author info
                const usersResponse = await fetch('tables/users');
                const usersData = await usersResponse.json();
                const users = usersData.data || [];
                
                // Merge posts with user data
                const postsWithUsers = data.data.map(post => {
                    const author = users.find(u => u.id === post.user_id);
                    return {
                        ...post,
                        author: author || {
                            username: 'Unknown',
                            full_name: 'Unknown User',
                            avatar_url: 'https://ui-avatars.com/api/?name=U&background=cccccc&color=fff'
                        }
                    };
                });

                this.posts = reset ? postsWithUsers : [...this.posts, ...postsWithUsers];
                this.renderPosts(reset);
                
                // Show/hide load more button
                const loadMoreBtn = document.getElementById('load-more-btn');
                if (data.data.length === this.postsPerPage) {
                    loadMoreBtn.style.display = 'inline-block';
                } else {
                    loadMoreBtn.style.display = 'none';
                }
            } else {
                if (reset) {
                    this.renderEmptyState();
                }
                document.getElementById('load-more-btn').style.display = 'none';
            }
        } catch (error) {
            console.error('Error loading posts:', error);
            this.showError('Failed to load posts. Please try again.');
        } finally {
            this.isLoading = false;
        }
    }

    renderPosts(reset = false) {
        const container = document.getElementById('posts-container');
        
        if (reset) {
            container.innerHTML = '';
        }

        if (this.posts.length === 0) {
            this.renderEmptyState();
            return;
        }

        this.posts.forEach(post => {
            const postElement = this.createPostElement(post);
            container.appendChild(postElement);
        });
    }

    createPostElement(post) {
        const postDiv = document.createElement('div');
        postDiv.className = 'card post-card fade-in';
        postDiv.dataset.postId = post.id;

        const timeAgo = this.getTimeAgo(post.created_at);
        const content = this.truncateContent(post.content, 200);
        const upvotes = post.upvotes || 0;
        const downvotes = post.downvotes || 0;
        const comments = post.comments_count || 0;

        postDiv.innerHTML = `
            <div class="card-body">
                <div class="post-header">
                    <div class="post-avatar">
                        <img src="${post.author.avatar_url}" alt="${post.author.full_name}" style="width: 100%; height: 100%; border-radius: 50%; object-fit: cover;">
                    </div>
                    <div class="post-meta">
                        <div class="post-author">${post.author.full_name}</div>
                        <div class="post-time">@${post.author.username} • ${timeAgo}</div>
                    </div>
                    <div class="ms-auto">
                        <span class="post-category">${post.category}</span>
                    </div>
                </div>
                
                <h5 class="post-title">${this.escapeHtml(post.title)}</h5>
                <div class="post-content">${this.renderContent(content)}</div>
                
                <div class="post-stats">
                    <div class="vote-buttons">
                        <button class="vote-btn" onclick="postsManager.votePost('${post.id}', 'up')" title="Upvote">
                            <i class="bi bi-arrow-up-circle"></i>
                        </button>
                        <span class="vote-count">${upvotes - downvotes}</span>
                        <button class="vote-btn" onclick="postsManager.votePost('${post.id}', 'down')" title="Downvote">
                            <i class="bi bi-arrow-down-circle"></i>
                        </button>
                    </div>
                    
                    <div class="post-stat" onclick="postsManager.viewPost('${post.id}')">
                        <i class="bi bi-chat-dots"></i>
                        <span>${comments} Comments</span>
                    </div>
                    
                    <div class="post-stat" onclick="postsManager.sharePost('${post.id}')">
                        <i class="bi bi-share"></i>
                        <span>Share</span>
                    </div>
                    
                    ${this.currentUserCanEdit(post) ? `
                        <div class="post-stat" onclick="postsManager.editPost('${post.id}')">
                            <i class="bi bi-pencil"></i>
                            <span>Edit</span>
                        </div>
                        <div class="post-stat" onclick="postsManager.deletePost('${post.id}')">
                            <i class="bi bi-trash"></i>
                            <span>Delete</span>
                        </div>
                    ` : ''}
                </div>
            </div>
        `;

        return postDiv;
    }

    renderContent(content) {
        // Convert markdown-like syntax to HTML
        let html = this.escapeHtml(content);
        
        // Simple formatting
        html = html
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/g, '<em>$1</em>')
            .replace(/`(.*?)`/g, '<code>$1</code>')
            .replace(/\n/g, '<br>');
        
        return html;
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    truncateContent(content, maxLength) {
        if (content.length <= maxLength) return content;
        return content.substr(0, maxLength) + '...';
    }

    getTimeAgo(timestamp) {
        const now = new Date();
        const postTime = new Date(timestamp);
        const diffMs = now - postTime;
        const diffMins = Math.floor(diffMs / 60000);
        const diffHours = Math.floor(diffMs / 3600000);
        const diffDays = Math.floor(diffMs / 86400000);

        if (diffMins < 1) return 'just now';
        if (diffMins < 60) return `${diffMins}m ago`;
        if (diffHours < 24) return `${diffHours}h ago`;
        if (diffDays < 30) return `${diffDays}d ago`;
        return postTime.toLocaleDateString();
    }

    currentUserCanEdit(post) {
        if (!window.authManager.isLoggedIn()) return false;
        const currentUser = window.authManager.getCurrentUser();
        return currentUser.id === post.user_id || currentUser.is_admin;
    }

    renderEmptyState() {
        const container = document.getElementById('posts-container');
        container.innerHTML = `
            <div class="text-center py-5">
                <div class="mb-4">
                    <i class="bi bi-inbox display-1 text-muted"></i>
                </div>
                <h4 class="text-muted mb-3">No posts yet</h4>
                <p class="text-muted mb-4">Be the first to share your teaching ideas with the community!</p>
                ${window.authManager.isLoggedIn() ? 
                    `<button class="btn btn-primary" onclick="postsManager.showCreatePostModal()">
                        <i class="bi bi-plus-circle me-2"></i>Create Post
                    </button>` :
                    `<button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#registerModal">
                        Join Community
                    </button>`
                }
            </div>
        `;
    }

    showError(message) {
        const container = document.getElementById('posts-container');
        container.innerHTML = `
            <div class="alert alert-danger" role="alert">
                <i class="bi bi-exclamation-triangle me-2"></i>${message}
            </div>
        `;
    }

    filterByCategory(category) {
        // Update active button
        document.querySelectorAll('[data-category]').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.category === category);
        });

        this.currentFilter = category;
        this.loadPosts(true);
    }

    searchPosts() {
        const searchInput = document.getElementById('search-input');
        this.searchQuery = searchInput.value.trim();
        this.loadPosts(true);
    }

    loadMorePosts() {
        this.currentPage++;
        this.loadPosts();
    }

    showCreatePostModal() {
        if (!window.authManager.requireAuth(() => this.showCreatePostModal())) {
            return;
        }

        // Create modal if it doesn't exist
        if (!document.getElementById('createPostModal')) {
            this.createCreatePostModal();
        }

        const modal = new bootstrap.Modal(document.getElementById('createPostModal'));
        modal.show();
    }

    createCreatePostModal() {
        const modalHtml = `
            <div class="modal fade" id="createPostModal" tabindex="-1">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Create New Post</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <form id="create-post-form">
                                <div class="mb-3">
                                    <label for="post-title" class="form-label">Title *</label>
                                    <input type="text" class="form-control" id="post-title" required>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="post-category" class="form-label">Category *</label>
                                            <select class="form-select" id="post-category" required>
                                                <option value="">Select Category</option>
                                                <option value="Classroom Activities">Classroom Activities</option>
                                                <option value="Teaching Methods">Teaching Methods</option>
                                                <option value="Lesson Plans">Lesson Plans</option>
                                                <option value="Student Engagement">Student Engagement</option>
                                                <option value="Classroom Management">Classroom Management</option>
                                                <option value="Assessment Ideas">Assessment Ideas</option>
                                                <option value="Technology Integration">Technology Integration</option>
                                                <option value="Moroccan Curriculum">Moroccan Curriculum</option>
                                                <option value="Professional Development">Professional Development</option>
                                                <option value="General Discussion">General Discussion</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="post-grade" class="form-label">Grade Level</label>
                                            <select class="form-select" id="post-grade">
                                                <option value="">Select Grade</option>
                                                <option value="Primary (1-6)">Primary (1-6)</option>
                                                <option value="Middle School (7-9)">Middle School (7-9)</option>
                                                <option value="High School (10-12)">High School (10-12)</option>
                                                <option value="All Levels">All Levels</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label for="post-content" class="form-label">Content *</label>
                                    <textarea class="form-control" id="post-content" rows="8" required></textarea>
                                </div>
                                <div class="alert alert-info">
                                    <small>
                                        <strong>Formatting Tips:</strong><br>
                                        Use **bold** for emphasis, *italic* for style, `code` for examples.
                                        Line breaks will be preserved.
                                    </small>
                                </div>
                                <div class="alert alert-danger d-none" id="create-post-error"></div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="button" class="btn btn-primary" id="submit-post-btn">Create Post</button>
                        </div>
                    </div>
                </div>
            </div>
        `;

        document.body.insertAdjacentHTML('beforeend', modalHtml);

        // Bind submit event
        document.getElementById('submit-post-btn').addEventListener('click', (e) => this.submitPost(e));
    }

    async submitPost(e) {
        e.preventDefault();
        
        const formData = {
            title: document.getElementById('post-title').value.trim(),
            category: document.getElementById('post-category').value,
            grade_level: document.getElementById('post-grade').value,
            content: document.getElementById('post-content').value.trim()
        };

        const errorDiv = document.getElementById('create-post-error');

        // Validation
        if (!formData.title || formData.title.length < 5) {
            this.showError(errorDiv, 'Title must be at least 5 characters');
            return;
        }

        if (!formData.category) {
            this.showError(errorDiv, 'Please select a category');
            return;
        }

        if (!formData.content || formData.content.length < 10) {
            this.showError(errorDiv, 'Content must be at least 10 characters');
            return;
        }

        try {
            const currentUser = window.authManager.getCurrentUser();
            const newPost = {
                id: this.generateId(),
                user_id: currentUser.id,
                title: formData.title,
                content: formData.content,
                category: formData.category,
                grade_level: formData.grade_level,
                upvotes: 0,
                downvotes: 0,
                is_published: true,
                created_at: new Date().toISOString(),
                updated_at: new Date().toISOString()
            };

            await this.createPost(newPost);
            
            bootstrap.Modal.getInstance(document.getElementById('createPostModal')).hide();
            this.showNotification('Post created successfully!', 'success');
            this.loadPosts(true);
            
        } catch (error) {
            console.error('Error creating post:', error);
            this.showError(errorDiv, 'Failed to create post. Please try again.');
        }
    }

    async createPost(post) {
        try {
            const response = await fetch('tables/posts', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(post)
            });
            
            if (!response.ok) {
                throw new Error('Failed to create post');
            }
            
            return await response.json();
        } catch (error) {
            console.error('Error creating post:', error);
            throw error;
        }
    }

    showError(element, message) {
        element.textContent = message;
        element.classList.remove('d-none');
        setTimeout(() => {
            element.classList.add('d-none');
        }, 5000);
    }

    showNotification(message, type = 'info') {
        window.authManager.showNotification(message, type);
    }

    generateId() {
        return 'post_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }

    viewPost(postId) {
        window.location.href = `post.html?id=${postId}`;
    }

    sharePost(postId) {
        const url = `${window.location.origin}/post.html?id=${postId}`;
        if (navigator.share) {
            navigator.share({
                title: 'Check out this teaching idea',
                url: url
            });
        } else {
            navigator.clipboard.writeText(url).then(() => {
                this.showNotification('Link copied to clipboard!', 'success');
            });
        }
    }

    votePost(postId, voteType) {
        if (!window.authManager.requireAuth(() => this.votePost(postId, voteType))) {
            return;
        }
        
        // Implement voting logic here
        this.showNotification('Vote recorded!', 'success');
    }

    editPost(postId) {
        // Implement edit functionality
        this.showNotification('Edit functionality coming soon!', 'info');
    }

    deletePost(postId) {
        if (confirm('Are you sure you want to delete this post?')) {
            this.showNotification('Delete functionality coming soon!', 'info');
        }
    }
}

// Initialize posts manager
window.postsManager = new PostsManager();